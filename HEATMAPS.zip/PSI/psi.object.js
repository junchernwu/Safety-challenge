var psimap;
$(document).ready(function() {
    psimap = L.map('psimap', {crs: L.CRS.EPSG4326}).setView([1.3521, 103.8198], 11);
	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox.streets',
    accessToken: 'your.mapbox.access.token'
}).addTo(psimap);
});
$.getJSON("http://127.0.0.1:8000/psi_reading.json", function(data) {
        console.log(data); // this will show the info it in firebug console
        var psi2DArr = data["features"][0]["geometry"]["coordinates"];
        for(var i in psi2DArr) {
        	// swap lng/lat
            var swap = psi2DArr[i][1];
            psi2DArr[i][1] = psi2DArr[i][0];
            psi2DArr[i][0] = swap;
            // set opacity for all the points
            psi2DArr[i].push(0.5);
        }
        var heat = L.heatLayer(psi2DArr, {radius: 15, blur: 8}).addTo(psimap);
});